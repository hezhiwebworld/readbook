


function addLog(pubData, cb) {
    // 规避wkb 不存在情况
    console.log(22222)
    try {
        wkb.call('getAppInfo', {
            success: function (appinfo) {
              console.log(appinfo)
              var temp = pubData.content[0].msgContent
              var logData = {
                "certSerial": "abcd",
                "clientId": "lianshangh5act.shengpay.com",
                "clientType": "lianshangh5act",
                "content": [{
                  "appId": "lianshangh5",
                  "msgContent": {
                    "page_name": temp.page_name || "",
                    "loading_duration": temp.loading_duration || "",
                    "page_starttime": temp.page_starttime || "",
                    "page_endtime": temp.page_endtime || "",
                    "button_name": temp.button_name || "",
                    'page_sarttime': temp.page_sarttime || '',
                    "awardNo": temp.awardNo || "",
                    "result": temp.result || "",
                    "getLocation": "",
                    "netMode": appinfo.netmode || "",
                    "dpi": window.devicePixelRatio || "",
                    "imei": appinfo.imei || "",
                    "manufacturer": appinfo.manufacturer || "",
                    "device": appinfo.device || "",
                    "model": appinfo.model || "",
                    "dhid": appinfo.dhid || "",
                    "uhid": appinfo.uhid || "",
                    "operateBind_sdk_version": appinfo.osvername || "",
                    "source": "anniversary",
                    "login_name": appinfo.ph || "",
                    "app_version": "",
                    "app_ID": "ZF1137",
                    "Objectid": new Date().getTime(),
                    "session_id": "",
                    "event_time": "",
                    "ext": "",
                    "input": "",
                    "URL": "",
                    "popup_name": "",
                    "content": "",
                    'wifi_version': appinfo.vcode || "",
                    'wifi_channel': appinfo.chanid || "",
                    "channel": "yx",
                    "version": "yx",
                  },
                  "msgType": pubData.content.msgType || ""
                }],
                "encryptType": "1",
                "sign": "423442309",
                "timeStamp": ""
              };
              $.extend(true, logData, pubData);
              console.log(logData)
              $.ajax({
                type: 'POST',
                url: 'https://rdtgatewaytest.shengpay.com/rdt-gateway/rest/message',
                data: JSON.stringify(logData),
                contentType: "application/json; charset=utf-8",
                dataType: 'json',
                // timeout: 1000,
                success: function () {
                  cb && cb()
                },
                error: function () {
                  cb && cb()
                }
              })
            }
          })
    } catch (error) {
      console.log(error)
    }
  }
  function getNowFormatDate(arg) {
    var date = arg ? new Date(arg) : new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    var hh = date.getHours();
    var mm = date.getMinutes();
    var ss = date.getSeconds();
    month = month < 10 ? '0' + month : month
    strDate = strDate < 10 ? '0' + strDate : strDate
    hh = hh < 10 ? '0' + hh : hh
    hh = hh < 10 ? '0' + hh : hh
    mm = mm < 10 ? '0' + mm : mm
    ss = ss < 10 ? '0' + ss : ss
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate +
      " " + hh + seperator2 + mm +
      seperator2 + ss + '.' + date.getTime().toString().substr(-3);
    return currentdate;
  }
  var loadingData = {
    'content':
      [{
        "msgContent": {
          'page_starttime': getNowFormatDate(),
          'page_name': window.location.pathname,
        },
        "msgType": 'pageLoading'
      }]
  };
  addLog(loadingData);

  $(function () {
    $('.item').on('click', 'div', function (ev) {
      var btnname = $(ev.currentTarget).parent().find('.btnname').text();
      var url = $(ev.currentTarget).parent().data('url');
      var pubData = {
        'content': [{
          "msgContent": {
            'page_name': window.location.pathname,
            'button_name': btnname,
            'page_sarttime': getNowFormatDate(),
          },
          "msgType": 'clickQuery'
        }]
      };
      console.log(url)
      console.log(btnname)
      addLog(pubData, function () {
        window.location.href = url
      });
    })
  })